export const OWNER_NUMBERS = [
  '6285715771858@s.whatsapp.net' // Ganti sesuai nomor kamu
]